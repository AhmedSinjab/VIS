package Chesspackage;

import javax.swing.JButton;
class ChessBoard {
    public static JButton button;
    private int x;
    private int y;
    boolean filled = false;

    public ChessBoard(int x, int y) {
        this.x = x;
        this.y = y;
     
    }

    public static JButton getButton() {
        return button;
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }
}
