package Chesspackage;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
/*
 * To Do:
 * 	1.make the chessBoard button objects
 * 		-Make the array of object buttons work and get the buttons working
 * 	2.Make the pieces logic
 */
class Chess {
	public static JFrame frame = new JFrame("Chess Board");
	
	public static ChessBoard[] boxes = new ChessBoard[128];
	static class ButtonListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			JButton btn = (JButton) e.getSource();
			System.out.println("Button pressed: " + btn.getName());
			
		}

	}

	public static void instailze() {

		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(800, 800);

		JPanel panel = new JPanel();
		panel.setLayout(new GridLayout(8, 8));
		panel.setSize(800, 800);
		int number = 0;
		for (int i = 0; i < 8; i++) {
			
			for (int j = 0; j < 8; j++) {
				
				boxes[number].button = new JButton();
				boxes[number].button.setName(i + "," + j);
				if ((i + j) % 2 == 0) {
					boxes[number].button.setBackground(Color.WHITE);
				} else {
					boxes[number].button.setBackground(Color.BLACK);
				}
				boxes[number].button.addActionListener(new Chess.ButtonListener());
				boxes[number] = new ChessBoard(i,j);
				panel.add(boxes[number].button);
			//	panel.add(boxes[number].getButton());
				number += 1;
			}
			number += 1;
		}

		frame.add(panel);
		frame.setVisible(true);
	}

	public static void main(String[] args) {
		instailze();

	}
}