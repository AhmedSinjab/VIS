package Chesspackage;

public class Piece {
	private String Color;
	private int X;
	private int Y;
	
	public void setColor(String InColor){
		this.Color = InColor;
	}
	public String getColor () {
		return this.Color;
		
	}
	public void setX(int x) {
		this.X = x;
	}
	public void setY(int y) {
		this.Y = y;
	}
	public int getX() {
		return this.X;
	}
	public int getY() {
		return this.Y;
	}
	public void isWhite(String Color, int CordX, int CordY) {
		if (Color == "white") {
			setX (CordX);
			setY (CordY);
			
		}
		else {
			setX(CordX);
			setY(0);
			}
	}
	public class King extends Piece{
		
	}
	public class Queen extends Piece{
		
	}
	public class Pawn extends Piece{
		
	}
	public class Bishop extends Piece{
		
	}
	public class Knight extends Piece{
		
	}
	public class rooks extends Piece{
		public rooks(String Acolor) {
			setColor(Acolor);
			isWhite(Acolor, 0 , 7);
			rooks SecondRook = new rooks(Acolor,  2);
		}
		public rooks(String Acolor, int second) {
			setColor(Acolor);
			isWhite(Acolor, 7  , 7);
			
		}
		
	}
}
